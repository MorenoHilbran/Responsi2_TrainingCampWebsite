<?php
$connect =mysqli_connect("localhost","root","","abn") or die ("gagal koneksi");
?>